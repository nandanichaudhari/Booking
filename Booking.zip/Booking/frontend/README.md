# Booking - Frontend (Vite + React + TypeScript + Tailwind)
## Setup
1. Install dependencies: `npm install`
2. Start dev server: `npm run dev`
3. Open http://localhost:5173
## Notes
- The frontend expects backend running at http://localhost:5000
- Tailwind is already configured in tailwind.config.cjs
