import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Details from './pages/Details'
import Checkout from './pages/Checkout'
import Result from './pages/Result'

export default function App(){
  return (
    <div>
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-teal-400 to-cyan-600 text-white flex items-center justify-center font-bold">B</div>
            <div>
              <div className="font-semibold">Booking</div>
              <div className="text-sm text-gray-500">Experiences & Slots</div>
            </div>
          </Link>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/details/:id" element={<Details/>} />
          <Route path="/checkout/:id" element={<Checkout/>} />
          <Route path="/result" element={<Result/>} />
        </Routes>
      </main>
    </div>
  )
}
