import { useLocation, Link } from 'react-router-dom'

export default function Result(){
  const { state } = useLocation() as any
  return (
    <div className="max-w-xl mx-auto text-center">
      {state?.success ? (
        <div className="card p-8">
          <h2 className="text-2xl font-bold text-green-600">Booking Confirmed 🎉</h2>
          <p className="mt-2">{state.message}</p>
          <div className="mt-4 font-semibold">Total: ₹{state.totalPrice}</div>
        </div>
      ) : (
        <div className="card p-8">
          <h2 className="text-2xl font-bold text-red-600">Booking Failed</h2>
          <p className="mt-2">{state?.message || 'Try again'}</p>
        </div>
      )}
      <Link to="/" className="inline-block mt-6 text-teal-600">Back to home</Link>
    </div>
  )
}
