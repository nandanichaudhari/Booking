import axios from 'axios'
import { useSearchParams, useParams, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'

export default function Checkout(){
  const [params] = useSearchParams()
  const { id } = useParams()
  const navigate = useNavigate()
  const slot = params.get('slot') || ''
  const [exp, setExp] = useState<any>(null)
  const [form, setForm] = useState({ name:'', email:'', phone:'', promo:'' })
  const [promoValid, setPromoValid] = useState<any>(null)
  useEffect(()=>{
    if(id) axios.get(`http://localhost:5000/experiences/${id}`).then(r=>setExp(r.data)).catch(()=>{})
  },[id])

  const checkPromo = async ()=>{
    if(!form.promo) return
    const r = await axios.post('http://localhost:5000/promo/validate', { code: form.promo }).catch(()=>({data:{valid:false}}))
    setPromoValid(r.data)
  }

  const submit = async ()=>{
    if(!form.name || !form.email) return alert('Name and email required')
    const body = { ...form, experienceId: id, slot }
    const r = await axios.post('http://localhost:5000/bookings', body).catch(e=>e.response)
    if(r?.data?.success) navigate('/result', { state: r.data })
    else navigate('/result', { state: { success:false, message: r?.data?.message || 'Failed' } })
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Checkout</h2>
      <div className="card p-4 mb-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-500">Experience</div>
            <div className="font-semibold">{exp?.title}</div>
          </div>
          <div>
            <div className="text-sm text-gray-500">Slot</div>
            <div className="font-semibold">{slot}</div>
          </div>
        </div>
      </div>
      <div className="card p-4 mb-4">
        <input className="w-full mb-2 p-2 border rounded" placeholder="Full name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        <input className="w-full mb-2 p-2 border rounded" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
        <input className="w-full mb-2 p-2 border rounded" placeholder="Phone (optional)" value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} />
        <div className="flex gap-2">
          <input className="flex-1 p-2 border rounded" placeholder="Promo code" value={form.promo} onChange={e=>setForm({...form, promo:e.target.value})} />
          <button onClick={checkPromo} className="px-3 py-1 rounded bg-gray-100">Apply</button>
        </div>
        {promoValid && promoValid.valid && <div className="mt-2 text-green-600">Promo applied!</div>}
        {promoValid && !promoValid.valid && <div className="mt-2 text-red-600">Invalid promo</div>}
      </div>
      <div className="flex gap-4">
        <button onClick={submit} className="px-4 py-2 rounded bg-gradient-to-r from-teal-400 to-cyan-600 text-white">Confirm booking</button>
      </div>
    </div>
  )
}
