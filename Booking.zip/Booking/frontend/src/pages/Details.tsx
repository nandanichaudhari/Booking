import axios from 'axios'
import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'

export default function Details(){
  const { id } = useParams()
  const navigate = useNavigate()
  const [exp, setExp] = useState<any>(null)
  const [slot, setSlot] = useState('')
  useEffect(()=>{
    if(!id) return
    axios.get(`http://localhost:5000/experiences/${id}`).then(r=>setExp(r.data)).catch(()=>{})
  },[id])
  if(!exp) return <div>Loading...</div>
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="md:col-span-2 card p-4">
        <img src={exp.image} className="w-full h-64 object-cover rounded-lg" />
        <h2 className="text-2xl font-bold mt-4">{exp.title}</h2>
        <p className="text-gray-600 mt-2">{exp.description}</p>
      </div>
      <div className="card p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-500">Duration</div>
            <div className="font-semibold">{exp.duration}</div>
          </div>
          <div>
            <div className="text-sm text-gray-500">Price</div>
            <div className="font-semibold">₹{exp.price}</div>
          </div>
        </div>
        <div className="mt-4">
          <h4 className="font-medium">Select Slot</h4>
          <div className="flex flex-wrap gap-2 mt-2">
            {exp.slots.map((s:any)=>(
              <button key={s.date} disabled={!s.available} onClick={()=>setSlot(s.date)}
                className={`px-3 py-1 rounded ${slot===s.date?'bg-teal-600 text-white':'border'}`}>
                {s.date}{!s.available?' (Sold out)':''}
              </button>
            ))}
          </div>
          <button disabled={!slot} onClick={()=> navigate(`/checkout/${id}?slot=${slot}`)}
            className="mt-6 w-full py-2 rounded bg-gradient-to-r from-teal-400 to-cyan-600 text-white disabled:opacity-60">
            Continue to Checkout
          </button>
        </div>
      </div>
    </div>
  )
}
