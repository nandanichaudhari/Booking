import axios from 'axios'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function Home(){
  const [items, setItems] = useState<any[]>([])
  useEffect(()=>{
    axios.get('http://localhost:5000/experiences').then(r=>setItems(r.data)).catch(()=>{})
  },[])
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Featured Experiences</h1>
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(x=> (
          <Link key={x._id} to={`/details/${x._id}`} className="card transition-transform transform hover:-translate-y-1">
            <img src={x.image} className="w-full h-44 object-cover" alt={x.title} />
            <div className="p-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{x.title}</h3>
                <div className="text-sm text-gray-600">⭐ {x.rating}</div>
              </div>
              <p className="text-sm text-gray-500 mt-2">{x.subtitle}</p>
              <div className="mt-4 flex items-center justify-between">
                <div className="text-lg font-bold">₹{x.price}</div>
                <button className="text-sm px-3 py-1 rounded bg-gradient-to-r from-teal-400 to-cyan-600 text-white">View</button>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
