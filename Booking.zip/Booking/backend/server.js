const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const MONGO = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/booking';

mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error', err));

// Models
const ExperienceSchema = new mongoose.Schema({
  title: String,
  subtitle: String,
  description: String,
  image: String,
  price: Number,
  duration: String,
  rating: Number,
  slots: [{ date: String, available: Boolean }],
});

const BookingSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: String,
  experienceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Experience', required: true },
  slot: String,
  promoCode: String,
  totalPrice: Number,
  createdAt: { type: Date, default: Date.now }
});

const Experience = mongoose.model('Experience', ExperienceSchema);
const Booking = mongoose.model('Booking', BookingSchema);

// Routes
app.get('/experiences', async (req, res) => {
  const items = await Experience.find();
  res.json(items);
});

app.get('/experiences/:id', async (req, res) => {
  const item = await Experience.findById(req.params.id);
  if(!item) return res.status(404).json({ error: 'Not found'});
  res.json(item);
});

app.post('/bookings', async (req, res) => {
  try {
    const { name, email, experienceId, slot, promoCode } = req.body;
    if(!name || !email || !experienceId || !slot) return res.status(400).json({ success:false, message: 'Missing required fields' });

    // Prevent double-booking for the same experience+slot by same email
    const exists = await Booking.findOne({ experienceId, slot, email });
    if(exists) return res.status(409).json({ success:false, message: 'You already booked this slot with this email' });

    // compute price (simple)
    const exp = await Experience.findById(experienceId);
    if(!exp) return res.status(400).json({ success:false, message: 'Invalid experience' });
    let total = exp.price;
    const promos = { SAVE10: { type: 'percent', amount: 10 }, FLAT100: { type: 'flat', amount: 100 } };
    if(promoCode && promos[promoCode]){
      const p = promos[promoCode];
      if(p.type === 'percent') total = total - (total * p.amount / 100);
      else total = Math.max(0, total - p.amount);
    }

    const booking = new Booking({ name, email, experienceId, slot, promoCode, totalPrice: total });
    await booking.save();

    // mark slot unavailable
    await Experience.updateOne({ _id: experienceId, 'slots.date': slot }, { $set: { 'slots.$.available': false } });

    res.json({ success: true, message: 'Booking successful', bookingId: booking._id, totalPrice: total });
  } catch(e){
    console.error(e);
    res.status(500).json({ success:false, message: 'Server error' });
  }
});

app.post('/promo/validate', (req, res) => {
  const { code } = req.body;
  const promos = { SAVE10: { type: 'percent', amount: 10 }, FLAT100: { type: 'flat', amount: 100 } };
  if(code && promos[code]) return res.json({ valid: true, promo: promos[code] });
  res.json({ valid: false });
});

app.listen(PORT, ()=> console.log('Server running on port', PORT));
