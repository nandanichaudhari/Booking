# Booking - Backend
## Setup (Local MongoDB)
1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env` and ensure `MONGO_URI` is `mongodb://127.0.0.1:27017/booking`
3. Seed sample data: `npm run seed`
4. Start server: `npm run dev` (requires nodemon) or `npm start`
Server runs on http://localhost:5000
