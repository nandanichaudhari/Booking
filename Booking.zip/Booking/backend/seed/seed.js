const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();
const MONGO = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/booking';
mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true }).then(()=> console.log('Connected')).catch(e=>console.error(e));

const ExperienceSchema = new mongoose.Schema({
  title: String, subtitle: String, description: String, image: String, price: Number, duration: String, rating: Number, slots: [{ date: String, available: Boolean }]
});
const Experience = mongoose.model('Experience', ExperienceSchema);

const data = [
  {
    title: 'Beach Camping at Goa',
    subtitle: 'Sun, sand and bonfires',
    description: 'Enjoy a 2-day beach camping experience with local cuisine and music. Perfect for couples and groups.',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=',
    price: 3000,
    duration: '2 days',
    rating: 4.7,
    slots: [
      { date: '2025-11-05', available: true },
      { date: '2025-11-10', available: true }
    ]
  },
  {
    title: 'Hiking the Western Ghats',
    subtitle: 'Sunrise summit trek',
    description: 'A challenging trek with stunning sunrise views. Includes guide, breakfast and campfire.',
    image: 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=',
    price: 2500,
    duration: '1 day',
    rating: 4.8,
    slots: [
      { date: '2025-11-12', available: true },
      { date: '2025-11-19', available: true }
    ]
  }
];

async function seed(){
  await Experience.deleteMany({});
  await Experience.insertMany(data);
  console.log('Seeded');
  process.exit(0);
}
seed();
