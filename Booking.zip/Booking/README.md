# Booking (Fullstack)
This project contains a frontend (Vite + React + TypeScript + Tailwind) and a backend (Node + Express + MongoDB).

## Quick start (local)
1. Make sure you have Node.js and MongoDB installed and running locally.
2. Backend:
   - `cd backend`
   - `npm install`
   - Copy `.env.example` to `.env` (MONGO_URI defaults to mongodb://127.0.0.1:27017/booking)
   - `npm run seed`   # seeds sample experiences
   - `npm run dev` or `npm start`
3. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm run dev`
4. Open http://localhost:5173 in your browser.

## Promo codes supported
- SAVE10  => 10% off
- FLAT100 => ₹100 off

## What I included
- API endpoints: GET /experiences, GET /experiences/:id, POST /bookings, POST /promo/validate
- Sample data seeded
- Simple Figma-inspired styling (spacing, rounded cards, gradients)
